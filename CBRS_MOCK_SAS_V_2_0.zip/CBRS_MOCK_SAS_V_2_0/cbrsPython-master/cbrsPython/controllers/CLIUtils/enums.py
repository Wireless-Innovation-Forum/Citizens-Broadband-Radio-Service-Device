from enum import Enum
class TestStatus(Enum):
    PASSED = "passed"
    FAILED = "failed"
    
class StepStatus(Enum):
    PASSED = "passed"
    FAILED = "failed"