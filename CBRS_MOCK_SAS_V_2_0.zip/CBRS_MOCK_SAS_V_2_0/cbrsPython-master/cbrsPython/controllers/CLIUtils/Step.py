'''
Created on Apr 23, 2017

@author: iagmon
'''

class Step(object):
    '''
    classdocs
    '''


    def __init__(self,jsonFileName,index):
        '''
        Constructor
        '''
        self.jsonOfStep = jsonFileName
        self.index = index
        