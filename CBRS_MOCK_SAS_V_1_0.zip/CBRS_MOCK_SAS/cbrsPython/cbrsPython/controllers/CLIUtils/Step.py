'''
Created on Apr 23, 2017

@author: iagmon
'''

class Step(object):
    '''
    classdocs
    '''


    def __init__(self,jsonFileName):
        '''
        Constructor
        '''
        self.jsonOfStep = jsonFileName
        